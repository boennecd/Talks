---
title: "Gains of Complicated Distress Model: Danish Evidence"
bibliography: bibliography.bib
output: 
  revealjs::revealjs_presentation: 
    theme: simple
    keep_md: true
    center: false
    transition: slide
    css: css/styles.css
    self_contained: true
    reveal_options:
      slideNumber: true
    includes:
      in_header: header.html
      after_body: doc_suffix.html
---

## dummy slide

<!--javascript to remove dummy slide-->
<script>
document.getElementById("dummy-slide").remove();
</script>

<!--end dummy slide-->
</section>



<section>
<section class="titleslide slide level1">
<h1>Talk overview</h1>



<div class="left">

Problem and data.  

Four models.

1. Generalized linear model (logit).
2. Generalized additve model.  
3. Gradient tree boosting.  
4. Generalized linear mixed model.

</div>
</section>
</section>


<section class="titleslide slide level1">
<h1>Main conclusions</h1>
<div class="left">
<p class="fragment">There are gains of more complex models on some metrics.</p>

<p class="fragment">The gains are smaller than suggested in recent papers.</p>

<p class="fragment">The more complex models does not overcome issues temporal effects.</p> 

<p class="fragment">The temporal effects can be addressed with random effects models.</p> 
</div>

</section>



<section>
<section class="titleslide slide level1">
<h1>Problem and data</h1>

All ApS and A/S  
<small>Financial statements from Experian.</small>

Outcome: in distress period.  
<small>"Tvangsopløsning" or default.</small>

Winsorize ratios with denominator
$$\text{size}_{it} = \max(\text{equity}_{it}, 0) + \text{debt}_{it}$$
<small>Similar issue as in @Campbell08.</small>

<!-- there is a end tag from the previous slide -->
<!-- </section> -->



## What is an event?

Discrete hazard models  
<small>as in @Shumway01.</small>  

A case is last financial statement before distress period 
<small>within two years.</small>

Recurrent events and censoring.



## Event example

![](fig\outcome_ex_case.JPG)

<small>Circle: a new financial statement. Cross: enters distress period.</small>



## Only control example

![](fig\outcome_ex_control.JPG)

</section>
<!-- need extra end tag before next section -->
</section>



<section>
<section class="titleslide slide level1">
<h1>Generalized linear model (GLM)</h1>

Variable selection with two-stage LASSO procedure.  
<small>See @buhlmann11 and @Zhou10.</small>

<small>Examples of GLM PD models are @Shumway01, @Chava04, @Beaver05, and @Campbell08.</small>

<!-- there is a end tag from the previous slide -->
<!-- </section> -->



## Model
<div class="left">
$$\begin{array}{l}
E(Y_{it}\vert \vec{x}_{it}) = p_{it} \\
\text{log}(p_{it}/(1 - p_{it})) = \vec{\beta}^\top\vec{x}_{it} + 
\vec{\gamma}^\top\vec{z}_t  \\ 
\underset{\vec{\beta},\vec{\gamma}}{\text{argmax}}\, 
L(\vec{Y}; \vec{\beta}, \vec{\gamma})
\end{array}$$

<small>where $\vec{x}_{it}$ are firm specific variables and $\vec{z}_t$ are macro variables.</small>

<!--TODO: make sure figures are right-->

Final model has $57$ firms specific variables and $1$ macro variable. 

</div>


## Macro variables

Take first component from PCA. Explains $63.23$ pct. of the variation in 2015.

<table border="1" frame="void" rules="all">
<tr>
<th>Variable</th>
<th>Loading</th>
</tr>
<tr>
<td>Unemployment rate</td>
<td>0.5636</td>
</tr>
<tr>
<td>Real rate</td>
<td>0.5752</td>
</tr>
<tr>
<td>Real rate</td>
<td>0.5875</td>
</tr>
<tr>
<td>Inflation</td>
<td>0.0799</td>
</tr>
</table>



## Estimates

![](fig\plot_coef_est-1.png)

<small>Inner line: coefficients with standardized covariates. Outer lines: 95% Wald confidence intervals.</small>



## Estimates

![](fig\plot_coef_est-2.png)

<small>Inner line: coefficients with standardized covariates. Outer lines: 95% Wald confidence intervals.</small>



## Estimates

![](fig\plot_coef_est-3.png)

<small>Inner line: coefficients with standardized covariates. Outer lines: 95% Wald confidence intervals.</small>



## Estimates

![](fig\plot_coef_est-4.png)

<small>Inner line: coefficients with standardized covariates. Outer lines: 95% Wald confidence intervals.</small>



## Estimates

![](fig\plot_coef_est-5.png)

<small>Inner line: coefficients. Outer lines: 95% Wald confidence intervals.</small>



## Estimates

![](fig\plot_coef_est-6.png)

<small>Inner line: coefficients. Outer lines: 95% Wald confidence intervals.</small>

</section>
<!-- need extra end tag before next section -->
</section>



<section>
<section class="titleslide slide level1">
<h1>Generalized additive model (GAM)</h1>
<div class="left">
Cubic regression splines with second order penalties.  
<small>See @Wood17 and @Wood15</small>

<!--TODO: make sure figures are right-->
GAM has an AIC of $323895$ ($197.2$ df) while GLM has $327851$ ($59$ df).

<small>Examples of GAM PD models are @Dakovic10 and @Daniel07.</small>
</div>
<!-- there is a end tag from the previous slide -->
<!-- </section> -->



## Marginal effect in GLM and GAM

![](fig\aars_ratio_plot.png)

<small>Line: effect in GLM. Curve: effect in GAM with 2 standard error bounds.</small>



## Marginal effect GAM

![](fig/gam_interaction_3D.png)



## Marginal effect GAM

![](fig/gam_interaction.png)

<small>Lower value means lower likelihood of default.</small>



## Model
<div class="left">
<small>
$$\begin{align*}
E(Y_{it}\vert \vec{x}_{it}) &= p_{it} \\
\text{log}(p_{it}/(1 - p_{it})) &= 
\begin{aligned}[t]
   &\vec{\beta}_1^\top\vec{x}_{1it} + 
   \sum_{j=1}^q\vec{\beta}_{2j}^\top\vec{f}_j(x_{2ijt}) \\
   &+ \sum_{k = 1}^r \sum_{(j,l,s)\in S_k} \vec{\beta}_{3kj} f_{ls}(x_{3ilt})\vec{f}_{j}(x_{3ijt}) \\
   &+ \vec{\gamma}^\top\vec{z}_t
\end{aligned} \\
\underset{\vec{\beta},\vec{\gamma}}{\text{argmax}} &\, 
L(\vec{Y}; \vec{\beta}, \vec{\gamma}) - \vec{\beta} S_{\vec{\lambda}} \vec{\beta}
\end{align*}$$
</small>

<small>Use generalized cross validation to select $\vec{\lambda}$</small>
</div>

</section>
<!-- need extra end tag before next section -->
</section>



<section>
<section class="titleslide slide level1">
<h1>Gradient tree boosting (GB)</h1>

<div class="left">

Sequential approximations of the gradient.
<small>See @Friedman01, @Friedman02, and @Buhlmann07.</small>

<p>Used implementation is common method in winning solution on <a href="https://www.kaggle.com">kaggle.com</a>.</p> 

<div class = "center"> 
<img src="fig/kaggle_logo.png" class="small"> 
<img src="fig/xgboost.png" class="small"> 
</div> 

<small>Examples of GB PD models are @Alfaro08, @Zieba16 and @Jones17.</small>

</div>

<!-- there is a end tag from the previous slide -->
<!-- </section> -->



## Estimation

<div class="left">

Define loss function and initialize linear predictors. Then

1. Compute gradient of loss function.
2. Train simple model (shallow tress) to fit the gradient. 
3. Update linear predictors and repeat 1.

</div>

## Choosing shrinkage parameter and depth

![](fig\xgboost_cv_auc.png)

<small>Select tree depth and number of boosting iteration with $K$-fold cross validation.</small>



## Example with first tree

![](fig\first_tree.png)


## Variable importance

![](fig\var_importance.png)

<small>Relative improvement in log likelihood. See @Friedman01.</small>



</section>
<!-- need extra end tag before next section -->
</section>



<section>
<section class="titleslide slide level1">
<h1>Comparison</h1>
Out sample test using expanding window.  
<small>E.g., estimate with 2001-2007 data and forecast 2009.</small>

<!-- there is a end tag from the previous slide -->
<!-- </section> -->




## What is the AUC

<div class="left">
AUC: Area Under the ROC Curve. 

Probability of **ranking** random distressed firm at higher risk than random non-distressed firm.

$0.5$ is random guessing and 1 is perfect order. 

$$\text{AUC} = \frac{1}{2}(\text{Gini coef} - 1)$$
</div>



## What is the AUC

![](presentation_files/figure-revealjs/auc_example-1.png)


## AUC -- all firms

![](fig\auc_all.png)



## AUC -- large firms

![](fig\auc_large.png)

<!--TODO: make sure figures are right-->

<small>21% of the firms and 92% of total short and long term debt.</small>

## Mean log score

$$\text{avg log score}_t = -\frac{1}{\vert R_t\vert}
\sum_{i\in R_t}\left(y_{it}\log\hat{p}_{it} + (1 - y_{it})\log(1 - \hat{p}_{it})\right)$$

Half of mean of deviance residuals.   



## Mean log score -- all firms

![](fig\log_score_all.png)

<small>Y-value is relative to the GLM. Numbers indicate the mean log score for the GLM. Circle areas are proportional to mean log score of GLM.</small>



## Predicted level of distress -- all

![](fig\predict_level_all.png)



## Predicted level of distress -- large

![](fig\predict_level_large.png)



## Risk weighted debt

![](fig\risk_weighted_debt.png)

<small>Debt is long and short term debt on balance sheet.</small>

</section>
<!-- need extra end tag before next section -->
</section>



<section>
<section class="titleslide slide level1">
<h1>Generalized linear mixed models (GLMM)</h1>
Add time dependent random effects.  
<small>See @Bates04 and @Bates15.</small>

<small>Examples of GLMM PD models are @Duffie09, @Koopman11, @Azizpour16, @Nickerson17, and @kwon18.</small>

<!-- there is a end tag from the previous slide -->
<!-- </section> -->



## Model
$$\begin{array}{l}
E(Y_{it}\vert \vec{x}_{it}) = p_{it} \\
\text{log}(p_{it}/(1 - p_{it})) = \vec{\beta}^\top\vec{x}_{it} + 
\vec{\gamma}^\top\vec{z}_t + 
\vec{\epsilon}_t^\top\vec{u}_{it} \qquad 
\vec{\epsilon}_t\sim N(\vec{0}, Q) \\
\underset{\vec{\beta},\vec{\gamma}, Q}{\text{argmax}}\, 
L(\vec{Y}; \vec{\beta}, \vec{\gamma},Q)
\end{array}$$



## Random intercept

$$\beta_{0t} = \beta_0 + \epsilon_t, \qquad \epsilon_t \sim N(0, \sigma^2)$$

<!--TODO: make sure figures are right-->

$\hat{\sigma} = 0.266$.  
<small>Conservative $\chi^2_{(1)}$ statistics is 1590 with $H_0:\, \sigma = 0$.</small>

<!-- First principal component is no longer significant with Wald test. -->

## Conditional modes

![](fig/intercept_rng_modes_only_inter.png)



## 2017 prediction -- defaults

![](fig/lme4_defaults.png)



## 2017 prediction -- debt

![](fig/lme4_debt.png)



## Random intercept and log size slope

$$\begin{pmatrix}
\epsilon_{\text{intercept},t}\\
\epsilon_{\log(\text{size}),t}
\end{pmatrix} \sim N \left(
\vec{0}, Q
\right), \qquad 
\widehat{Q} = \begin{pmatrix} 0.0965 & 0.0291 \\ 0.0291 & 0.0175 \end{pmatrix}$$

<!--TODO: make sure figures are right-->

Correlation is high -- $0.71$.



## Random intercept and log_size slope

![](fig/intercept_rng_modes_both_size.png)

Fixed slope estimate is $-0.1443$.

</section>
<!-- need extra end tag before next section -->
</section>



<section class="titleslide slide level1">
<h1>Conclusions</h1>
<div class="left">
<!--TODO: check match with previous-->

There are gains of more complex models on some metrics.

The gains are smaller than suggested in recent papers.

The more complex models does not overcome issues temporal effects. 

The temporal effects can be addressed with random effects models. 
</div>
</section>


<section class="titleslide slide level1">
<h1>References</h1>

<!-- </section> -->
